library(testthat)
library(DALEX)
library(ingredients)

test_check("ingredients")
